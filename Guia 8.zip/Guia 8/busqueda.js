//Definir la matriz o arreglo con los datos
var lista = new Array("Aerobic","Ajedrez","Atletismo","Beisbol","Badminton","Baloncesto","Boxeo","Ciclismo","Equitacio","Esgrima",
"Futbol","Gimnasia artistica","Equitacion","Judo","Lanzamiento de disco","Lanzamiento de jabalina","Levantamiento de pesas","Lucha","Natacion",
"Natacion sincronizada","Patinaje","Pentatlon","Remo","Salto alto","Salto largo","Tenis","Tenis de mesa","Tiro con arco","Voleibol","Waterpolo");
